## Download the data

- all: `snakemake`
- chip-nexus only: `snakemake chip_nexus`
- chip-seq only: `snakemake chip_seq`